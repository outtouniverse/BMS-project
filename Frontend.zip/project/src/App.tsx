import React, { useState } from 'react';
import { 
  FileText, 
  Calculator, 
  Shield, 
  CheckCircle, 
  TrendingUp, 
  Users, 
  Clock, 
  ArrowRight, 
  Menu, 
  X,
  Star,
  BarChart3,
  Zap,
  Globe,
  Award,
  Phone,
  Mail,
  MapPin
} from 'lucide-react';

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="bg-white border-b border-gray-100 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <div className="flex items-center">
              <div className="flex items-center justify-center w-10 h-10 bg-black rounded-lg mr-3">
                <FileText className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl font-bold text-gray-900">GST Portal</span>
            </div>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center space-x-8">
              <a href="#" className="text-gray-700 hover:text-black font-medium transition-colors">Home</a>
              <a href="#" className="text-gray-700 hover:text-black font-medium transition-colors">Services</a>
              <a href="#" className="text-gray-700 hover:text-black font-medium transition-colors">Solutions</a>
              <a href="#" className="text-gray-700 hover:text-black font-medium transition-colors">Pricing</a>
              <a href="#" className="text-gray-700 hover:text-black font-medium transition-colors">Support</a>
              <button className="bg-black text-white px-6 py-2 rounded-lg font-medium hover:bg-gray-800 transition-colors">
                Login
              </button>
            </div>

            {/* Mobile menu button */}
            <div className="md:hidden">
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="text-gray-700 hover:text-black"
              >
                {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>

          {/* Mobile Navigation */}
          {isMenuOpen && (
            <div className="md:hidden border-t border-gray-100 py-4">
              <div className="flex flex-col space-y-4">
                <a href="#" className="text-gray-700 hover:text-black font-medium">Home</a>
                <a href="#" className="text-gray-700 hover:text-black font-medium">Services</a>
                <a href="#" className="text-gray-700 hover:text-black font-medium">Solutions</a>
                <a href="#" className="text-gray-700 hover:text-black font-medium">Pricing</a>
                <a href="#" className="text-gray-700 hover:text-black font-medium">Support</a>
                <button className="bg-black text-white px-6 py-2 rounded-lg font-medium hover:bg-gray-800 transition-colors w-fit">
                  Login
                </button>
              </div>
            </div>
          )}
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative bg-white overflow-hidden">
        {/* Background Elements */}
        <div className="absolute inset-0">
          <div className="absolute top-20 left-20 w-32 h-32 bg-gray-900 rounded-full opacity-5"></div>
          <div className="absolute top-40 right-32 w-24 h-24 bg-black rounded-lg rotate-45 opacity-10"></div>
          <div className="absolute bottom-32 left-32 w-40 h-40 border-4 border-gray-200 rounded-full"></div>
          <div className="absolute bottom-20 right-20 w-16 h-16 bg-gray-800 rounded-lg opacity-15"></div>
          
          {/* Connecting Lines */}
          <svg className="absolute inset-0 w-full h-full" viewBox="0 0 1200 800">
            <path d="M200 150 Q400 200 600 100" stroke="#e5e7eb" strokeWidth="2" fill="none" opacity="0.5"/>
            <path d="M100 400 Q400 350 700 500" stroke="#d1d5db" strokeWidth="1" fill="none" opacity="0.3"/>
            <path d="M800 200 Q900 300 1000 250" stroke="#e5e7eb" strokeWidth="2" fill="none" opacity="0.4"/>
          </svg>
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center">
            <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6 leading-tight">
              Navigating the<br />
              <span className="text-gray-600">GST landscape</span><br />
              for success
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto leading-relaxed">
              Streamline your GST compliance with our comprehensive digital platform designed for modern businesses. 
              Simplify tax filing, manage returns, and stay compliant with ease.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="bg-black text-white px-8 py-4 rounded-xl font-semibold hover:bg-gray-800 transition-all duration-200 transform hover:scale-105 flex items-center justify-center">
                Get Started Today
                <ArrowRight className="ml-2 w-5 h-5" />
              </button>
              <button className="border-2 border-gray-300 text-gray-700 px-8 py-4 rounded-xl font-semibold hover:border-black hover:text-black transition-all duration-200">
                Watch Demo
              </button>
            </div>
          </div>
        </div>

        {/* Trusted By Section */}
        <div className="bg-gray-50 py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <p className="text-center text-gray-500 mb-8 font-medium">Trusted by leading businesses across India</p>
            <div className="flex flex-wrap justify-center items-center gap-8 md:gap-16 opacity-60">
              <div className="text-lg font-bold text-gray-400 tracking-wider">RELIANCE</div>
              <div className="text-lg font-bold text-gray-400 tracking-wider">TATA</div>
              <div className="text-lg font-bold text-gray-400 tracking-wider">INFOSYS</div>
              <div className="text-lg font-bold text-gray-400 tracking-wider">WIPRO</div>
              <div className="text-lg font-bold text-gray-400 tracking-wider">HDFC</div>
              <div className="text-lg font-bold text-gray-400 tracking-wider">ICICI</div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Our Services</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Comprehensive GST solutions tailored for your business needs
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Service Card 1 */}
            <div className="bg-gray-50 rounded-2xl p-8 border border-gray-100 hover:shadow-lg transition-all duration-300 group">
              <div className="w-12 h-12 bg-black rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                <Calculator className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">GST Calculator</h3>
              <p className="text-gray-600 mb-4">Calculate GST amounts instantly with our advanced calculator tool</p>
              <div className="flex items-center text-black font-medium">
                Learn more <ArrowRight className="ml-2 w-4 h-4" />
              </div>
            </div>

            {/* Service Card 2 */}
            <div className="bg-black rounded-2xl p-8 text-white hover:shadow-lg transition-all duration-300 group">
              <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                <FileText className="w-6 h-6 text-black" />
              </div>
              <h3 className="text-xl font-bold mb-3">Return Filing</h3>
              <p className="text-gray-300 mb-4">Automated GST return filing with error-free submissions</p>
              <div className="flex items-center font-medium">
                Learn more <ArrowRight className="ml-2 w-4 h-4" />
              </div>
            </div>

            {/* Service Card 3 */}
            <div className="bg-gray-50 rounded-2xl p-8 border border-gray-100 hover:shadow-lg transition-all duration-300 group">
              <div className="w-12 h-12 bg-black rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                <Shield className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Compliance Check</h3>
              <p className="text-gray-600 mb-4">Ensure 100% compliance with automated validation checks</p>
              <div className="flex items-center text-black font-medium">
                Learn more <ArrowRight className="ml-2 w-4 h-4" />
              </div>
            </div>

            {/* Service Card 4 */}
            <div className="bg-gray-50 rounded-2xl p-8 border border-gray-100 hover:shadow-lg transition-all duration-300 group">
              <div className="w-12 h-12 bg-black rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                <BarChart3 className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Analytics</h3>
              <p className="text-gray-600 mb-4">Detailed insights and reports for better tax management</p>
              <div className="flex items-center text-black font-medium">
                Learn more <ArrowRight className="ml-2 w-4 h-4" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Feature Card 1 */}
            <div className="bg-white rounded-2xl p-8 shadow-sm border border-gray-100 relative overflow-hidden">
              <div className="absolute top-4 right-4 w-8 h-8 bg-gray-900 rounded-full opacity-10"></div>
              <div className="absolute bottom-4 left-4 w-6 h-6 bg-black rounded-lg rotate-45 opacity-5"></div>
              
              <div className="w-12 h-12 bg-gray-100 rounded-xl flex items-center justify-center mb-6">
                <Zap className="w-6 h-6 text-gray-700" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Lightning Fast Processing</h3>
              <p className="text-gray-600 mb-6">Process your GST returns in minutes, not hours. Our advanced algorithms ensure quick and accurate calculations.</p>
              <div className="flex items-center text-black font-medium">
                Explore feature <ArrowRight className="ml-2 w-4 h-4" />
              </div>
            </div>

            {/* Feature Card 2 */}
            <div className="bg-black rounded-2xl p-8 text-white relative overflow-hidden">
              <div className="absolute top-4 right-4 w-8 h-8 bg-white rounded-full opacity-10"></div>
              <div className="absolute bottom-4 left-4 w-6 h-6 bg-white rounded-lg rotate-45 opacity-5"></div>
              
              <div className="w-12 h-12 bg-white bg-opacity-20 rounded-xl flex items-center justify-center mb-6">
                <Globe className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-2xl font-bold mb-4">Multi-State Support</h3>
              <p className="text-gray-300 mb-6">Handle GST compliance across multiple states with unified dashboard and reporting.</p>
              <div className="flex items-center font-medium">
                Explore feature <ArrowRight className="ml-2 w-4 h-4" />
              </div>
            </div>

            {/* Feature Card 3 */}
            <div className="bg-black rounded-2xl p-8 text-white relative overflow-hidden">
              <div className="absolute top-4 right-4 w-8 h-8 bg-white rounded-full opacity-10"></div>
              <div className="absolute bottom-4 left-4 w-6 h-6 bg-white rounded-lg rotate-45 opacity-5"></div>
              
              <div className="w-12 h-12 bg-white bg-opacity-20 rounded-xl flex items-center justify-center mb-6">
                <Award className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-2xl font-bold mb-4">Expert Support</h3>
              <p className="text-gray-300 mb-6">Get assistance from certified GST experts whenever you need help with compliance or filing.</p>
              <div className="flex items-center font-medium">
                Explore feature <ArrowRight className="ml-2 w-4 h-4" />
              </div>
            </div>

            {/* Feature Card 4 */}
            <div className="bg-white rounded-2xl p-8 shadow-sm border border-gray-100 relative overflow-hidden">
              <div className="absolute top-4 right-4 w-8 h-8 bg-gray-900 rounded-full opacity-10"></div>
              <div className="absolute bottom-4 left-4 w-6 h-6 bg-black rounded-lg rotate-45 opacity-5"></div>
              
              <div className="w-12 h-12 bg-gray-100 rounded-xl flex items-center justify-center mb-6">
                <CheckCircle className="w-6 h-6 text-gray-700" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">99.9% Accuracy</h3>
              <p className="text-gray-600 mb-6">Our AI-powered validation ensures error-free GST calculations and submissions every time.</p>
              <div className="flex items-center text-black font-medium">
                Explore feature <ArrowRight className="ml-2 w-4 h-4" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Let's make things happen</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Join thousands of businesses who trust us with their GST compliance
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-gray-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Users className="w-8 h-8 text-gray-700" />
              </div>
              <div className="text-3xl font-bold text-gray-900 mb-2">50,000+</div>
              <div className="text-gray-600">Active Users</div>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-gray-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <FileText className="w-8 h-8 text-gray-700" />
              </div>
              <div className="text-3xl font-bold text-gray-900 mb-2">2M+</div>
              <div className="text-gray-600">Returns Filed</div>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-gray-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Clock className="w-8 h-8 text-gray-700" />
              </div>
              <div className="text-3xl font-bold text-gray-900 mb-2">24/7</div>
              <div className="text-gray-600">Support Available</div>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-gray-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Star className="w-8 h-8 text-gray-700" />
              </div>
              <div className="text-3xl font-bold text-gray-900 mb-2">4.9/5</div>
              <div className="text-gray-600">Customer Rating</div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="bg-white rounded-3xl p-12 shadow-sm border border-gray-100 relative overflow-hidden">
            {/* Background Elements */}
            <div className="absolute top-8 right-8 w-16 h-16 bg-gray-900 rounded-full opacity-5"></div>
            <div className="absolute bottom-8 left-8 w-12 h-12 bg-black rounded-lg rotate-45 opacity-5"></div>
            
            <h2 className="text-4xl font-bold text-gray-900 mb-6">
              Ready to simplify your GST compliance?
            </h2>
            <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
              Join thousands of businesses who have streamlined their GST processes with our platform. 
              Start your free trial today.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="bg-black text-white px-8 py-4 rounded-xl font-semibold hover:bg-gray-800 transition-all duration-200 transform hover:scale-105 flex items-center justify-center">
                Start Free Trial
                <ArrowRight className="ml-2 w-5 h-5" />
              </button>
              <button className="border-2 border-gray-300 text-gray-700 px-8 py-4 rounded-xl font-semibold hover:border-black hover:text-black transition-all duration-200">
                Schedule Demo
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {/* Company Info */}
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center mb-6">
                <div className="flex items-center justify-center w-10 h-10 bg-white rounded-lg mr-3">
                  <FileText className="w-6 h-6 text-black" />
                </div>
                <span className="text-xl font-bold">GST Portal</span>
              </div>
              <p className="text-gray-300 mb-6 max-w-md">
                Simplifying GST compliance for businesses across India. Our comprehensive platform 
                makes tax management effortless and accurate.
              </p>
              <div className="flex space-x-4">
                <div className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-gray-700 transition-colors cursor-pointer">
                  <span className="text-sm font-bold">f</span>
                </div>
                <div className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-gray-700 transition-colors cursor-pointer">
                  <span className="text-sm font-bold">t</span>
                </div>
                <div className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-gray-700 transition-colors cursor-pointer">
                  <span className="text-sm font-bold">in</span>
                </div>
              </div>
            </div>

            {/* Services */}
            <div>
              <h3 className="text-lg font-semibold mb-6">Services</h3>
              <ul className="space-y-4 text-gray-300">
                <li><a href="#" className="hover:text-white transition-colors">GST Registration</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Return Filing</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Tax Calculator</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Compliance Check</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Expert Support</a></li>
              </ul>
            </div>

            {/* Contact */}
            <div>
              <h3 className="text-lg font-semibold mb-6">Contact</h3>
              <ul className="space-y-4 text-gray-300">
                <li className="flex items-center">
                  <Phone className="w-4 h-4 mr-3" />
                  +91 1800-123-4567
                </li>
                <li className="flex items-center">
                  <Mail className="w-4 h-4 mr-3" />
                  support@gstportal.com
                </li>
                <li className="flex items-start">
                  <MapPin className="w-4 h-4 mr-3 mt-1" />
                  <span>123 Business District,<br />Mumbai, Maharashtra 400001</span>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">
              © 2025 GST Portal. All rights reserved.
            </p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">Privacy Policy</a>
              <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">Terms of Service</a>
              <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">Cookie Policy</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;